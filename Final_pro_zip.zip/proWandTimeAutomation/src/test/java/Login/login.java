package Login;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;

import utility.ConfigReader;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import java.io.IOException;
import java.time.Duration;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class login extends ConfigReader{

	 WebDriver driver = new ChromeDriver();

	@Test(priority=1)
	public void loginWand() throws IOException {
		new ConfigReader();

		//username click
		WebElement username = new WebDriverWait(driver, Duration.ofSeconds(15))
				.until(ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='text' and @id='usernamefield']")));
		username.click();
		username.clear();
		username.isSelected();
		username.sendKeys("sbhandari");

		// Password
		WebElement password = new WebDriverWait(driver, Duration.ofSeconds(15)).until(
				ExpectedConditions.elementToBeClickable(By.xpath("//input[@type='password' and @id='passwordfield']")));
		password.click();
		password.sendKeys(ConfigReader.getPassword());
		driver.findElement(By.xpath("//*[@type='submit' and @id='loginButton']")).click();

		//Time
		Select requirementTime = new Select(driver.findElement(By.xpath("//select[@id='selectedBillingType']")));
		  requirementTime.selectByValue("Time");
		  
		  
		  
	}

	@BeforeClass
	public void startSystem() throws IOException {
		new ConfigReader();
		driver.manage().window().maximize();
		driver.get(ConfigReader.getUrl());
	}

	
	@AfterClass
	public void systemClose() {
//		driver.quit();
	}
}

